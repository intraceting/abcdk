/*
 * This file is part of ABCDK.
 * 
 * Copyright (c) 2021 The ABCDK project authors. All Rights Reserved.
 * 
 */
#ifndef ABCDK_UTIL_GPIO_H
#define ABCDK_UTIL_GPIO_H

#include "abcdk/util/general.h"
#include "abcdk/util/trace.h"

__BEGIN_DECLS



__END_DECLS

#endif //ABCDK_UTIL_GPIO_H