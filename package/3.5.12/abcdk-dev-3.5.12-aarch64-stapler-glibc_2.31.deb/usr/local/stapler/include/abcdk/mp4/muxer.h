/*
 * This file is part of ABCDK.
 * 
 * Copyright (c) 2021 The ABCDK project authors. All Rights Reserved.
 * 
 */
#ifndef ABCDK_MP4_MUXER_H
#define ABCDK_MP4_MUXER_H

#include "abcdk/mp4/atom.h"

__BEGIN_DECLS



__END_DECLS

#endif //ABCDK_MP4_MUXER_H
