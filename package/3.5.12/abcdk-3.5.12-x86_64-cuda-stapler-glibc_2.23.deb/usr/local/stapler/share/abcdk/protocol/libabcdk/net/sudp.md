## 消息

|NONCE    |Data     |
|:--------|:--------|
|32 bytes |N bytes  |

* NONCE：NONCE码。
* DATA：变长数据。

