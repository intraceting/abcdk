## NONCE

|RANDOM   |TIME-MS |SEQ-NUM |
|:--------|:-------|:-------|
|16 bytes |8 bytes |8 bytes |

* RANDOM：随机字符。
* TIME-MS：时间戳(毫秒)。
* SEQ-NUM：编号。