/*
 * This file is part of ABCDK.
 * 
 * Copyright (c) 2021 The ABCDK project authors. All Rights Reserved.
 * 
 */
#ifndef ABCDK_UTIL_CRC32_H
#define ABCDK_UTIL_CRC32_H

#include "abcdk/util/crc.h"

#endif //ABCDK_UTIL_CRC32_H