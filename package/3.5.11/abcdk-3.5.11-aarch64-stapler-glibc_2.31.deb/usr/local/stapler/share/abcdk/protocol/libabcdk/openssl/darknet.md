## 头部

请求：

|VER    |KEY      |IV       |RES       |
|:------|:--------|:--------|:---------|
|1 byte |32 bytes |16 bytes |79 bytes  |

* VER：版本。
* KEY：密钥。
* IV：向量。
* RES：预留。
